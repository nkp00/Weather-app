export interface City {
    id:number,
    nm:string,
    lat:number,
    lon:number
  }